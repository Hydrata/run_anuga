# run_anuga
Run an ANUGA simulation using hydrata.com format.
